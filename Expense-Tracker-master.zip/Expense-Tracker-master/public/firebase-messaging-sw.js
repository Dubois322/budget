importScripts("https://www.gstatic.com/firebasejs/8.0.0/firebase-app.js")
importScripts("https://www.gstatic.com/firebasejs/8.0.0/firebase-messaging.js")

firebase.initializeApp({
  apiKey: "AIzaSyBzE0c-vSuFtTSg9jrQJNIDZmMSs2kzKfs",
  authDomain: "your-expense-tracker.firebaseapp.com",
  projectId: "your-expense-tracker",
  messagingSenderId: "676487835336",
  appId: "1:676487835336:web:8ad4dd941cd8a67f97bffd",
})

firebase.messaging()
